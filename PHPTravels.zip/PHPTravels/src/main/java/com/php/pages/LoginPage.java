package com.php.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.php.base.Base;

public class LoginPage extends Base {
	
	
	@FindBy(xpath="//input[@placeholder='Email']") WebElement userName;
	@FindBy(xpath="//input[@placeholder='Password']") WebElement password;
	@FindBy(xpath="//div[@class='mt-3 row']/preceding-sibling::button") WebElement lgnBtn;
	
	public LoginPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public void loginValidation(String username, String pwd)
	{
		userName.sendKeys(username);
		password.sendKeys(pwd);
		lgnBtn.click();
	}
}
